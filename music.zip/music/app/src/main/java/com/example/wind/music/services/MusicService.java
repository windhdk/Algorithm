package com.example.wind.music.services;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.Toast;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MusicService extends Service implements MediaPlayer.OnCompletionListener {

    private MediaPlayer mediaPlayer;

    private String musicPath = null;
    private int musicPosition = 0;
    private int ListLength = 0;
    private int messageTime = 1000;
    private String title = null;
    private String artist = null;

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    // 播放进度更新，1000微秒一更,通过广播形式提示UI更新
    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    if (mediaPlayer != null) {
                        int progress = mediaPlayer.getCurrentPosition();
                        Intent intent = new Intent("MusicService");
                        intent.putExtra("flag", "updateprogress");
                        intent.putExtra("progress", progress);
                        sendBroadcast(intent);
                        mHandler.sendEmptyMessageDelayed(1, 1000);
                    }
                    break;
                default:
                    break;
            }


        }
    };
    // onCreate之后被调用
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (intent != null) {
            Bundle bundle = intent.getExtras();
            ListLength= intent.getIntExtra("InfoLength",0);
            if (bundle != null) {
                String isPlayFirst = intent.getStringExtra("first");
                String path = intent.getStringExtra("url");
                title = intent.getStringExtra("title");
                artist = intent.getStringExtra("artist");
                if (isPlayFirst == null || isPlayFirst.equals("notfirst")) {
                    String operation = intent.getStringExtra("operation");
                    int position = intent.getIntExtra("position", 0);
                  //  ListLength = intent.getIntExtra("InfoLength", 0);
                    switch (operation) {
                        case "play":
                            play(path);
                            break;
                        case "pause":
                            pause();
                            break;
                        case "next":
                            changeMusic(path, position);
                            break;
                        case "pre":
                            changeMusic(path, position);
                            break;
                        case "randomClick":
                            changeMusic(path, position);
                            break;
                        case "autoNext":
                            changeMusic(path, position);
                            break;
                        case "progress":
                            changeProgress(intent.getIntExtra("progress", 0));
                            break;
                    }

                } else {
                   // ListLength = intent.getIntExtra("InfoLength", 0);
                    play(path);
                }

            }
        }
        mHandler.sendEmptyMessage(1);
        return super.onStartCommand(intent, flags, startId);
    }

    public void play(String path) {
        if (mediaPlayer == null) {
            changeMusic(path, 0);
        } else {
            mediaPlayer.start();
        }
    }

    public void pause() {
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        } else {
            mediaPlayer.start();
        }
    }

    public void changeMusic(String path, int position) {

        //记下当前音乐位置
        musicPath = path;
        musicPosition = position;

        //第一次播放则初始化播放资源
        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setOnCompletionListener(this);
        }

        try {
            // 切歌之前先重置，释放掉之前的资源
            mediaPlayer.reset();
            //Toast.makeText(this, "position"+musicPosition, Toast.LENGTH_SHORT).show();
            // 设置播放源
            mediaPlayer.setDataSource(path);
            // 开始播放前的准备工作，加载多媒体资源，获取相关信息
            mediaPlayer.prepare();
            // 开始播放
            mediaPlayer.start();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "播放错误", Toast.LENGTH_SHORT).show();
        }

        //更新播放信息，发送广播给MainActivity
        Intent intent = new Intent("MusicService");
        intent.putExtra("totalTime", parseTime(mediaPlayer.getDuration()));
        intent.putExtra("barMax", mediaPlayer.getDuration());
        intent.putExtra("title", title);
        intent.putExtra("artist", artist);
        intent.putExtra("flag", "updateTitle");
        sendBroadcast(intent);
        updateProgress();
    }

    @Override
    public void onCompletion(MediaPlayer mp) {

        if (musicPosition == ListLength - 1) {
            musicPosition = 0;
        } else {
            musicPosition = musicPosition + 1;
        }
      // Toast.makeText(this, "complete"+ musicPosition +"  :" +ListLength , Toast.LENGTH_SHORT).show();
        //广播信息播放完成，提示系统自动播放下一首
        Intent intent = new Intent("MusicService");
        intent.putExtra("position", musicPosition);
        intent.putExtra("flag", "autoNext");
        sendBroadcast(intent);
    }

    public void changeProgress(int progress) {
        //Toast.makeText(this, "progress" + progress, Toast.LENGTH_SHORT).show();
        mediaPlayer.seekTo(progress);
    }

    public void updateProgress() {
        // 使用Handler每间隔1s发送一次空消息，通知进度条更新
        Message msg = Message.obtain();// 获取一个现成的消息
        // 使用MediaPlayer获取当前播放时间除以总时间的进度
        int progress = mediaPlayer.getCurrentPosition();
        msg.arg1 = progress;
        mHandler.sendMessageDelayed(msg, messageTime);
    }

    // 解析时间
    private String parseTime(int oldTime) {
        SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");// 时间格式
        String newTime = sdf.format(new Date(oldTime));
        return newTime;
    }

}

package com.example.wind.music;


import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wind.music.Bean.Info;
import com.example.wind.music.services.MusicService;
import com.example.wind.music.util.musicUtil;

import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements  MediaPlayer.OnCompletionListener ,View.OnClickListener, SeekBar.OnSeekBarChangeListener {
    ListView musicListView;    //lsitview展示数据的
    SeekBar mSeekBar;         //seekbar 进度条显示
    TextView mCurrentTimeTv;     //播放时的时间
    TextView mTotalTimeTv;      //歌曲总时间
    Button up;                  //上一曲按钮
    Button play;                 //播放暂停按钮
    Button next;                  //下一曲按钮
    TextView now;               //当前播放歌曲名称
    private musicUtil util;  //音乐工具类，用于获取手机上的音乐
    private ArrayList<Info> musicList;  //装了音乐信息的listView
    private MusicAdapter adapter;
    private int currentposition=0;     //当前音乐播放位置
    private int currentProgress = 0 ;
    private String progressChange = "progress";
    private boolean isPlaying = false;
    private boolean isFirstTimePlay = true;
    private String musicPause = "pause";
    private String musicPlay = "play";
    private String musicNext = "next";
    private String musicPre = "pre";
    // 记录当前播放歌曲的位置
    private MediaPlayer mediaPlayer;
    private NotificationManager manager;
    private MyBrodcastReciver myBrodcastReciver;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        myBrodcastReciver = new MyBrodcastReciver();
        IntentFilter filter = new IntentFilter();
        filter.addAction("MusicService");
        registerReceiver(myBrodcastReciver, filter);

        mediaPlayer = new MediaPlayer();
        up.setOnClickListener(this);
        play.setOnClickListener(this);
        next.setOnClickListener(this);
        mSeekBar.setOnSeekBarChangeListener(this);
        mediaPlayer.setOnCompletionListener(this);
      //  mediaPlayer.setOnCompletionListener(this);//监听音乐播放完毕事件，自动下一曲
        initData();
    }

private void initView() {
    musicListView=findViewById(R.id.musicListView);
    mSeekBar=findViewById(R.id.sb);
    mCurrentTimeTv = findViewById(R.id.current_time_tv);
    mTotalTimeTv= findViewById(R.id.total_time_tv);
    up= findViewById(R.id.previous);
    play=findViewById(R.id.start_stop);
    next= findViewById(R.id.next);
    now =findViewById(R.id.now);
}
    /**
     * 初始化数据
     */
    private void initData() {
        util = new musicUtil();
        musicList = new ArrayList<>();
        musicList = util.getMusicInfo(this);
        adapter = new MusicAdapter();
        musicListView.setAdapter(adapter);
        musicListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                currentposition = position;     //获取当前点击条目的位置
                play.setText("暂停");
                isPlaying = true;
                if (isFirstTimePlay) {
                    isFirstTimePlay = false;
                }
                Intent intent=new Intent(MainActivity.this,MusicService.class);
                intent.putExtra("position",currentposition);
                intent.putExtra("InfoLength",musicList.size());
                intent.putExtra("url",musicList.get(currentposition).getUrl());
                intent.putExtra("title",musicList.get(currentposition).getTitle());
                intent.putExtra("artist",musicList.get(currentposition).getArtist());
                intent.putExtra("operation","randomClick");
                startService(intent);
            }
        });

    }

    @Override
    public void onBackPressed() {
        mediaPlayer.stop();
        mediaPlayer.release();
    }

    /**
     * 上一曲下一曲点击事件
     *
     * @param view
     */
    @Override
    public void onClick(View view) {
        Intent intent = new Intent().setClass(this, MusicService.class);
        intent.putExtra("InfoLength", musicList.size());
        if (isFirstTimePlay) {
            intent.putExtra("first", "first");
            intent.putExtra("url",musicList.get(0).getUrl());
            intent.putExtra("title",musicList.get(0).getTitle());
            intent.putExtra("artist",musicList.get(0).getArtist());
            isFirstTimePlay = false;
        } else {
            intent.putExtra("first", "notfirst");

        }
        switch (view.getId()) {
            case R.id.previous:
                playPreMusic();
                break;
            case R.id.next:
                playNextMusic();
                break;
            case R.id.start_stop:
                if (!isPlaying) {
                    play.setText("暂停");
                    intent.putExtra("operation", musicPlay);
                    intent.setPackage(getPackageName());
                    startService(intent);
                    isPlaying = true;
                } else {
                    play.setText("播放");
                    intent.putExtra("operation", musicPause);
                    intent.setPackage(getPackageName());
                    startService(intent);
                    isPlaying = false;
                }
                break;
        }

    }
    @Override
    public void onCompletion(MediaPlayer mp) {

        if (currentposition == musicList.size() - 1) {
            currentposition = 0;
        } else {
            currentposition = currentposition + 1;
        }
        //Toast.makeText(this, "complete"+ musicPosition +"  :" +ListLength , Toast.LENGTH_SHORT).show();
        //广播信息播放完成，提示系统自动播放下一首
        Intent intent = new Intent();
        intent.putExtra("position", currentposition);
        intent.putExtra("flag", "autoNext");
        sendBroadcast(intent);
    }

    public void playNextMusic() {
        currentposition = currentposition + 1;
        if (currentposition == musicList.size()) {
            currentposition = 0;
        }

        changeMusic(currentposition,musicNext);

    }

    public void playPreMusic() {
        //点击按钮，若当前歌曲播放时间不超过2秒，切换到上一曲；否则，重新播放当前歌曲
        if(currentProgress<2000){
            currentposition = currentposition - 1;
            if (currentposition == -1) {
                currentposition = musicList.size() - 1;
            }
        }
        changeMusic(currentposition,musicPre);

    }

    public void changeMusic(int c_position,String status){

        if(play.getText().equals("播放")){
            play.setText("暂停");
        }
        isPlaying = true;
        Intent intent = new Intent().setClass(this, MusicService.class);
        intent.putExtra("position",c_position);
        intent.putExtra("InfoLength",musicList.size());
        intent.putExtra("url",musicList.get(c_position).getUrl());
        intent.putExtra("title",musicList.get(c_position).getTitle());
        intent.putExtra("artist",musicList.get(c_position).getArtist());
        intent.putExtra("operation",status);
        startService(intent);

    }
    // 解析时间
    private String parseTime(int oldTime) {
        SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");// 时间格式
        String newTime = sdf.format(new Date(oldTime));
        return newTime;
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    // 当手停止拖拽进度条时执行该方法
    // 获取拖拽进度
    // 将进度对应设置给MediaPlayer
    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        if(isFirstTimePlay){
            Toast.makeText(this, "当前未播放音乐", Toast.LENGTH_SHORT).show();
        }else{
            int progress = seekBar.getProgress();
            changeProgress(progress);
        }
    }

    //手动拖拽进度条改变播放进度
    public void changeProgress(int progress) {
        Intent intent=new Intent(MainActivity.this,MusicService.class);
        intent.putExtra("position",currentposition);
        intent.putExtra("InfoLength",musicList.size());
        intent.putExtra("url",musicList.get(currentposition).getUrl());
        intent.putExtra("title",musicList.get(currentposition).getTitle());
        intent.putExtra("artist",musicList.get(currentposition).getArtist());
        intent.putExtra("operation",progressChange);
        intent.putExtra("progress", progress);
        startService(intent);

    }

    public void autoNextMusic(int position) {
        //Toast.makeText(this, "get position"+position, Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(MainActivity.this,MusicService.class);
        intent.putExtra("position",position);
        intent.putExtra("InfoLength",musicList.size());
        intent.putExtra("url",musicList.get(position).getUrl());
        intent.putExtra("title",musicList.get(position).getTitle());
        intent.putExtra("artist",musicList.get(position).getArtist());
        intent.putExtra("operation", "autoNext");
        startService(intent);
    }

    public Bitmap getArtAlbum(long audioId) {
        String str = "content://media/external/audio/media/" + audioId + "/albumart";
        Uri uri = Uri.parse(str);
        ParcelFileDescriptor pfd = null;
        try {
            pfd = this.getContentResolver().openFileDescriptor(uri, "r");
        } catch (FileNotFoundException e) {
            return null;
        }
        Bitmap bm;
        if (pfd != null) {
            FileDescriptor fd = pfd.getFileDescriptor();
            bm = BitmapFactory.decodeFileDescriptor(fd);
            return bm;
        }
        return null;
    }

    //音乐播放器的适配器
    public class MusicAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return musicList.size();
        }

        @Override
        public Info getItem(int position) {
            return musicList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (convertView == null) {
                convertView = View.inflate(MainActivity.this, R.layout.music_item, null);
                viewHolder = new ViewHolder();
                viewHolder.video_imageView = convertView.findViewById(R.id.video_imageView);
                viewHolder.video_title = convertView.findViewById(R.id.video_title);
                viewHolder.video_singer = convertView.findViewById(R.id.video_singer);
                /* viewHolder.video_duration = convertView.findViewById(R.id.video_duration);*/
                //  viewHolder.video_size = convertView.findViewById(R.id.video_size);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            Info item = getItem(position);
            viewHolder.video_singer.setText("歌手:" + item.getArtist());
            // viewHolder.video_size.setText((int) item.getSize());
            viewHolder.video_title.setText("歌名:" + item.getTitle());
            /* viewHolder.video_duration.setText(item.getDuration());*/
            if (getArtAlbum(item.getAbulm_id()) == null) {
                viewHolder.video_imageView.setImageResource(R.drawable.music);
            } else {
                viewHolder.video_imageView.setImageBitmap(getArtAlbum(item.getAbulm_id()));
            }

            return convertView;
        }
    }

    static class ViewHolder {
        ImageView video_imageView;
        TextView video_title;
        TextView video_singer;
      /*  TextView video_duration;
        TextView video_size;*/
    }
    public class MyBrodcastReciver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String flag = intent.getStringExtra("flag");
            if (flag.equals("updateprogress")) {
                int now_progress = intent.getIntExtra("progress", 0);
                mSeekBar.setProgress(now_progress);
                mCurrentTimeTv.setText(parseTime(now_progress));
                currentProgress = now_progress ;
            } else if (flag.equals("updateTitle")) {
                now.setText(intent.getStringExtra("title") + "\t" + "\t" +"歌手: " + intent.getStringExtra("artist"));
                mTotalTimeTv.setText(intent.getStringExtra("totalTime"));
                mSeekBar.setMax(intent.getIntExtra("barMax", 100));
                mSeekBar.setProgress(0);
            } else if (flag.equals("autoNext")) {
                currentposition = intent.getIntExtra("position", 0);
                autoNextMusic(currentposition);
            }
        }
    }
}


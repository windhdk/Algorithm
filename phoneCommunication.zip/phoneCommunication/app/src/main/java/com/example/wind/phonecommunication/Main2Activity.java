package com.example.wind.phonecommunication;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {

    EditText connect;
    EditText message_edit;
    Button return_button;
    Button send_button;
    String phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        connect = findViewById(R.id.edit);
        return_button = findViewById(R.id.return_button);
        send_button = findViewById(R.id.send_button);
        message_edit = findViewById(R.id.message_edit);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        phone = bundle.getString("phone");
        connect.setText(phone);
        send_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String info = message_edit.getText().toString();
                /* Uri smsUri = Uri.parse("tel:" + phone);
                Intent intent = new Intent(Intent.ACTION_SENDTO, smsUri);
                intent.putExtra("sms_body", "info");
                intent.setType("vnd.android-dir/mms-sms");
                 startActivity(intent);*/
               String number=connect.getText().toString();
                Intent intent= new Intent();
                intent.setAction(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("smsto:"+number));
                intent.putExtra("sms_body", info);
                startActivity(intent);


            }
        });
        return_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Main2Activity.this.setResult(2);
                Main2Activity.this.finish();
            }
        });
    }
}

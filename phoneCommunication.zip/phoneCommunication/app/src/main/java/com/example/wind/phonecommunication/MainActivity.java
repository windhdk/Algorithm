/*
* Android选择联系人并返回对应号码网址:https://blog.csdn.net/u010356768/article/details/79352323
* 这个网址代码还没有弄明白！！！！
* */

package com.example.wind.phonecommunication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
EditText phoneNumber;
Button dial;
Button choose_connect;
Button send;
String phonenumber;
private static final int PICK_CONTACT = 1;
    private static final int SEND_MESSAGE = 3;
private static final int PERMISSIONS_REQUEST_READ_CONTACTS = 2;
private Intent mIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        phoneNumber=(EditText)findViewById(R.id.phonenumber);
        dial=findViewById(R.id.dial);
        send=findViewById(R.id.send);
        choose_connect=findViewById(R.id.choose_connect);
        dial.setOnClickListener(this);
        send.setOnClickListener(this);
        choose_connect.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.dial:
                phonenumber = phoneNumber.getText().toString();
                Intent intentPhone = new Intent(Intent.ACTION_CALL);
                Uri data = Uri.parse("tel:" + phonenumber);
                intentPhone.setData(data);
                startActivity(intentPhone);
            break;
            case R.id.send:
                Intent intent=new Intent(MainActivity.this,Main2Activity.class);
                Bundle bundle=new Bundle();
                phonenumber = phoneNumber.getText().toString();
                bundle.putString("phone",phonenumber);
                intent.putExtras(bundle);
                startActivityForResult(intent,SEND_MESSAGE);
                break;
            case R.id.choose_connect:
                Intent intentNumber = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(intentNumber, PICK_CONTACT);
                break;
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode==PICK_CONTACT) {
            mIntent = data;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                //申请授权，第一个参数为要申请用户授权的权限；第二个参数为requestCode 必须大于等于0，主要用于回调的时候检测，匹配特定的onRequestPermissionsResult。
                // 可以从方法名requestPermissions以及第二个参数看出，是支持一次性申请多个权限的，系统会通过对话框逐一询问用户是否授权。
                requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, PERMISSIONS_REQUEST_READ_CONTACTS);
            } else {
                //如果该版本低于6.0，或者该权限已被授予，它则可以继续读取联系人。
                getContacts(data);
            }
        }
      else if(requestCode==2) {
            phoneNumber.setText("");
        }else{

            super.onActivityResult(requestCode, resultCode, data);

        }
    }
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSIONS_REQUEST_READ_CONTACTS) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 用户成功授予权限
                getContacts(mIntent);
            }
            else {
                Toast.makeText(this, "你拒绝了此应用对读取联系人权限的申请！", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void getContacts(Intent data) {
        if (data == null) {
            return;
           }
        Uri contactData = data.getData();
        if (contactData == null) {
            return;
        }
        Uri contactUri = data.getData();
        //Cursor 是每行的集合
        Cursor cursor = getContentResolver().query(contactUri, null, null, null, null);
        if (cursor.moveToFirst()) {
            String hasPhone = cursor .getString(cursor .getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));
            String id = cursor.getString(cursor .getColumnIndex(ContactsContract.Contacts._ID));
            if (hasPhone.equalsIgnoreCase("1")) {
                hasPhone = "true";
            } else {
                hasPhone = "false";
            }
            if (Boolean.parseBoolean(hasPhone)) {
                Cursor phones = getContentResolver() .query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + id, null, null);
                while (phones.moveToNext()) {
                    phonenumber = phones .getString(phones .getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                }
                phones.close();
            } cursor.close();

            phoneNumber.setText(phonenumber); } }

}

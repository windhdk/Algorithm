package com.example.wind.myapplication;
//MainActivity ------------ 主Activity



import android.content.Intent;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;

import android.view.Menu;

import android.view.View;

import android.widget.Button;

import android.widget.EditText;

import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText editText,editText2;

    private Button button;

    @Override

    protected void onCreate(Bundle savedInstanceState)

    {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        button=(Button)findViewById(R.id.button2);

        editText = (EditText) findViewById(R.id.inputUserName);

        editText2 = (EditText)findViewById(R.id.inputpassword);

        button.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                Intent intent=new Intent(MainActivity.this,abaka.class);

                String s1 = editText.getText().toString();

                String s2 = editText2.getText().toString();

                startActivityForResult(intent,1000);

            }

        });

    }

    @Override

    protected void onActivityResult(int requestCode,int resultCode,Intent data){

        super.onActivityResult(requestCode,resultCode,data);

        if(requestCode == 1000 && resultCode == 1001){

            String result = data.getStringExtra("result");

            String result2 = data.getStringExtra("result2");

            editText.setText(result);

            editText2.setText(result2);

        }

    }

}

package com.example.wind.myapplication;


//abaka -------------- 子Activity


import android.content.Intent;

import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;

import android.widget.Button;

import android.widget.EditText;

import android.widget.TextView;

public class abaka extends AppCompatActivity {

    private EditText editText,editText2;

    private TextView textView,textView2;

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.content_abaka);

        editText = (EditText)findViewById(R.id.inputUserName);

        editText2 = (EditText)findViewById(R.id.inputpassword);

        Intent intent = getIntent();

        Button button=(Button)findViewById(R.id.button);

        Button button2=(Button)findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                String result = editText.getText().toString();

                String result2 = editText2.getText().toString();

                Intent intent = new Intent();

                intent.putExtra("result",result);

                intent.putExtra("result2",result2);

                setResult(1001,intent);

                finish();

            }

        });

        button2.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v)

            {

                Intent intent=new Intent(abaka.this,MainActivity.class);

                startActivity(intent);

            }

        });

    }

}

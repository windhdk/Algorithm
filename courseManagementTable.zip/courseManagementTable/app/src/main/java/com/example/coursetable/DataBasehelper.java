package com.example.coursetable;
/*
* NULL，值是NULL

  INTEGER，值是有符号整形，根据值的大小以1,2,3,4,6或8字节存放

  REAL，值是浮点型值，以8字节IEEE浮点数存放

  TEXT，值是文本字符串，使用数据库编码（UTF-8，UTF-16BE或者UTF-16LE）存放

  BLOB，只是一个数据块，完全按照输入存放（即没有准换）
* */
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBasehelper extends SQLiteOpenHelper {

    public DataBasehelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    private static final String DB_CREATE="create table courses(" +
            "course_id text primary key ," +
            "course_name text," +
            "teacher text," +
            "class_room text," +
            "day integer," +
            "class_start integer," +
            "class_end integer," +
            "credit real)";             // REAL，值是浮点型值，以8字节IEEE浮点数存放

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DB_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + "courses");
        onCreate(db);
    }
}

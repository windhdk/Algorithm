package com.example.coursetable;

import java.io.Serializable;

public class Course implements Serializable {
    private String course_id;
    private String courseName;
    private String teacher;
    private String classRoom;
    private int day;
    private int classStart;
    private int classEnd;
    private float credit;

    public Course(String course_id,String courseName, String teacher, String classRoom, int day, int classStart, int classEnd ,float credit) {
        this.course_id=course_id;
        this.courseName = courseName;
        this.teacher = teacher;
        this.classRoom = classRoom;
        this.day = day;
        this.classStart = classStart;
        this.classEnd = classEnd;
        this.credit=credit;
    }


    public  String getCourse_id(){return course_id;}

    public  void setCourse_id(String course_id){this.course_id=course_id;}

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public String getClassRoom() {
        return classRoom;
    }

    public void setClassRoom(String classRoom) {
        this.classRoom = classRoom;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getStart() {
        return classStart;
    }

    public void setStart(int classStart) {
        this.classEnd = classStart;
    }

    public int getEnd() {
        return classEnd;
    }

    public void setEnd(int classEnd) {
        this.classEnd = classEnd;
    }

    public  float getCredit(){return credit;}

    public  void setCredit(float course_id){this.credit=credit;}

}


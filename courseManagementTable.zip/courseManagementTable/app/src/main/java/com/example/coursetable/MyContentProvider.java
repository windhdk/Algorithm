

package com.example.coursetable;
/*
	如果想要访问内容提供器中共享的数据，就一定要借助ContentResolve类，可以通过Context中的getContentResolver()方法获取到该类的实例
内容 URI最标准的格式写法如下：

content://com.example.app.provider/table1   (这就表示调用方期望访问的是 com.example.app 这个应用的 table1 表中的数据。)
content://com.example.app.provider/table1/1 (这就表示调用方期望访问的是 com.example.app 这个应用的 table1表中 id 为 1 的数据。)

    我们可以使用通配符的方式来分别匹配这两种格式的内容 URI，规则如下
        *：表示匹配任意长度的任意字符
        '#：表示匹配任意长度的数字

	content://com.example.app.provider/*    (所以，一个能够匹配任意表的内容 URI格式就可以写成：)
    content://com.example.app.provider/table1/#      (而一个能够匹配 table1表中任意一行数据的内容 URI格式就可以写成：)



   contneResolver的query函数的理解网址：https://blog.csdn.net/wssiqi/article/details/8132603
 */
/*
* 存在问题：
*         1、不是很了解UriMatcher的addURI的path（这里指的是表名）后面加的通配符的意思?
* */
import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.provider.Contacts;
import android.util.Log;


public class MyContentProvider extends ContentProvider {

    private static final String TAG = "function";
    private static final String DB_NAME = "CourseTable.db";
    private static final String DB_TABLE = "courses";
    private static final int DB_VERSION = 1;
    private static final String AUTHORITY="com.example.coursetable.MyContentProvider";

    private SQLiteDatabase db;
    private DataBasehelper dataBasehelper;

    private static final int MULTIPLE_COURSE = 1;
    private static final int SINGLE_COURSE = 2;
    private static final UriMatcher uriMatcher;
    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(AUTHORITY, DB_TABLE, MULTIPLE_COURSE);//任意文本（表的属性值）匹配
        uriMatcher.addURI(AUTHORITY, DB_TABLE+"/#", SINGLE_COURSE);//根据数字（表的属性值）匹配
    }
public MyContentProvider(){
    Log.e(TAG, "MyContentProvider: +++++++++++++");
}
    @Override
    public boolean onCreate() {
        Context context = getContext();
        dataBasehelper = new DataBasehelper(context, DB_NAME, null, DB_VERSION);
        db = dataBasehelper.getReadableDatabase();
        if (db == null)
            return false;
        else
            return true;
    }

    @Override
    public Cursor query(Uri uri,  String[] projection,  String selection,  String[] selectionArgs, String sortOrder) {

        Log.e(TAG, "query: ");
        //匹配Uri，返回code
        int code = uriMatcher.match(uri);
        //得到连接对象
        SQLiteDatabase database = dataBasehelper.getReadableDatabase();
        //如果合法，进行对应的操作
        if (code == 1) {
            //不根据数字查询
            Cursor cursor = database.query("courses", projection, selection, selectionArgs, null, null, null);
            return cursor;
        } else if (code == 2) {
            //根据id 查询
            //得到id
            long id = ContentUris.parseId(uri); //这个方法负责把content URI 后边的id解析出来
            //查询
            Cursor cursor = database.query("courses", projection,
                    selection, new String[]{id + ""}, null, null, null, null);
            return cursor;
        } else {
            //如果不合法，抛出异常
            throw new RuntimeException("查询的uri不合法");
        }
    }

    @Override
    public String getType(Uri uri) {
            Log.d(TAG, "getType: ");
            return null;
        }


    @Override
    public Uri insert( Uri uri,ContentValues values) {
        Log.d(TAG, "insert: ");
        //得到连接对象
        SQLiteDatabase database = dataBasehelper.getReadableDatabase();
        //匹配Uri，返回code
        int code = uriMatcher.match(uri);
        //如果合法，进行对应的操作
        if (code == 1) {
            long id = database.insert("courses", null, values);
            //将id添加到uri中
            uri = ContentUris.withAppendedId(uri, id);
            database.close();
            return uri;
        } else {
            database.close();
            //如果不合法，抛出异常
            throw new RuntimeException("添加的uri不合法");
        }

    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {

        Log.d(TAG, "delete:");
        //得到连接对象
        SQLiteDatabase database = dataBasehelper.getReadableDatabase();
        //匹配Uri，返回code
        int code = uriMatcher.match(uri);
        int deleteCount = -1;
        //如果合法，进行对应的操作
        if (code == 1) {
            deleteCount = database.delete("courses", selection, selectionArgs);
        } else if (code == 2) {
            long id = ContentUris.parseId(uri);
            deleteCount = database.delete("courses", "course_id=" + id, null);
        } else {
            database.close();
            //如果不合法，抛出异常
            throw new RuntimeException("删除的uri不合法");
        }
        return deleteCount;
    }

    @Override
     public int update( Uri uri,ContentValues values, String selection,String[] selectionArgs) {
        Log.d(TAG, "update: ");

        //得到连接对象
        SQLiteDatabase database = dataBasehelper.getReadableDatabase();
        //匹配Uri，返回code
        int code = uriMatcher.match(uri);
        int updateCount = -1;
        //如果合法，进行对应的操作
        if (code == 1) {
            updateCount = database.update("courses", values, selection, selectionArgs);
        } else if (code == 2) {
            long id = ContentUris.parseId(uri);
            updateCount = database.update("courses",values, "course_id=" + id, null);
        } else {
            database.close();
            //如果不合法，抛出异常
            throw new RuntimeException("更新的uri不合法");
        }
        return updateCount;

    }

}

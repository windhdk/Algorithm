package com.example.coursetable;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class AddCourseActivity extends AppCompatActivity {
    static int BACK = 2;
    Uri uri;
    private ContentResolver contentResolver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);
        setFinishOnTouchOutside(false);
        final EditText inputCourseID=(EditText)findViewById(R.id.add_id_Course);
        final EditText inputCourseName = (EditText) findViewById(R.id.add_name_Course);
        final EditText inputTeacher = (EditText) findViewById(R.id.add_teacher);
        final EditText inputClassRoom = (EditText) findViewById(R.id.add_classroom);
        final EditText inputDay = (EditText) findViewById(R.id.add_day);
        final EditText inputStart = (EditText) findViewById(R.id.add_classStart);
        final EditText inputEnd = (EditText) findViewById(R.id.add_classEnd);
        final EditText inputCredit = (EditText) findViewById(R.id.add_credit);
        contentResolver=this.getContentResolver();
        uri= Uri.parse("content://com.example.coursetable.MyContentProvider/courses");

        Button okButton = (Button) findViewById(R.id.add);
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String courseID = inputCourseID.getText().toString();
                String courseName = inputCourseName.getText().toString();
                String teacher = inputTeacher.getText().toString();
                String classRoom = inputClassRoom.getText().toString();
                String day = inputDay.getText().toString();
                String start = inputStart.getText().toString();
                String end = inputEnd.getText().toString();
                String credit=inputCredit.getText().toString();

                if (courseID.equals("")||courseName.equals("")
                        || day.equals("") || start.equals("") ||
                        end.equals("") || credit.equals("") ||
                        teacher.equals("") || classRoom.equals("")) {
                    Toast.makeText(AddCourseActivity.this, "基本课程信息未填写完", Toast.LENGTH_SHORT).show();
                }
                else if(false ==checkNumber(courseID)){
                    Toast.makeText(AddCourseActivity.this, "学号按照XX00000格式填写", Toast.LENGTH_SHORT).show();
                }
                else  if (Float.valueOf(credit) * 10 % 5 != 0) {
                    Toast.makeText(AddCourseActivity.this, "学分必须为0.5的倍数" ,Toast.LENGTH_SHORT).show();
                }
                else if("notNull".equals(matchID(courseID))){
                    Toast.makeText(AddCourseActivity.this, "学号已经重复，请确认再添加" ,Toast.LENGTH_SHORT).show();
                }
                else if("notNull".equals(matchCourseName(courseName))){
                    Toast.makeText(AddCourseActivity.this, "课程名程已经重复，请确认再添加" ,Toast.LENGTH_SHORT).show();
                }
                else {
                    Course course = new Course(courseID,courseName, teacher, classRoom,
                    Integer.valueOf(day), Integer.valueOf(start), Integer.valueOf(end),Float.valueOf(credit));
                    Intent intent = new Intent(AddCourseActivity.this, MainActivity.class);
                    intent.putExtra("course", course);

                    setResult(Activity.RESULT_OK, intent);
                    finish();
                }
            }
        });
        Button back=(Button)findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddCourseActivity.this, MainActivity.class);
                setResult(BACK, intent);
                finish();
            }
        });
    }

    public static boolean checkNumber(String str) {
        String regex = "[A-Z]{2}[\\d]{5}$";
        return Pattern.matches(regex, str);
    }

    public String matchID(Object str){
        String courseID="null";
        final Cursor cursor=contentResolver.query(uri,null,"course_id = ?",new String[]{str.toString() },null);
        while (cursor.moveToNext()) {
             courseID=cursor.getString(0);
        }
       if(str.equals(courseID)){
           return  "notNull";
       }else{
           return "null";
       }
}
    public String matchCourseName(Object str){
        String courseName="null";
        final Cursor cursor=contentResolver.query(uri,null,"course_name = ?",new String[]{str.toString() },null);
        while (cursor.moveToNext()) {
            courseName=cursor.getString(0);
        }
        if(str.equals(courseName)){
            return  "notNull";
        }else{
            return "null";
        }
    }
}

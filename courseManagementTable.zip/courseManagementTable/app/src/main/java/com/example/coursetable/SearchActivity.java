package com.example.coursetable;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchActivity extends AppCompatActivity {

    EditText ed_number;
    Button confirm;
    Uri uri;
    private ContentResolver contentResolver;
    Context mycontext;
    private ListView list;

    private SimpleAdapter simpleAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        initView();
        mycontext=this;
    }
    public void initView(){
        ImageView back=(ImageView)findViewById(R.id.backView);
        ed_number=(EditText) findViewById(R.id.number);
        confirm=(Button) findViewById(R.id.searchBtn);
        list = (ListView) findViewById(R.id.list);
        contentResolver=this.getContentResolver();
        uri= Uri.parse("content://com.example.coursetable.MyContentProvider/courses");

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SearchActivity.this,MainActivity.class);
                setResult(3,intent);
                finish();
            }
        });
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager manager = ((InputMethodManager) SearchActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE));
                if (manager != null) {
                    manager.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }

                Editable numberText = ed_number.getText();
                final Cursor cursor=contentResolver.query(uri,null,"course_id = ?",new String[]{numberText.toString() },null);
                List<Map<String, String>> data = new ArrayList<>();

                while (cursor.moveToNext()) {
                    Map<String, String> map = new HashMap<String, String>() {{
                        put("name", cursor.getString(1));
                        put("number", cursor.getString(0));
                        put("room", cursor.getString(3));
                        put("teacher", cursor.getString(2));
                        put("credit",cursor.getFloat(7)+"");
                    }};
                    data.add(map);
                }
                simpleAdapter = new SimpleAdapter(SearchActivity.this,
                        data,
                        R.layout.subject_list_item,
                        new String[]{"name", "number", "room", "teacher","credit"},
                        new int[]{R.id.name, R.id.number_show, R.id.room, R.id.teacher_show,R.id.credit_show});
                list.setAdapter(simpleAdapter);
            }
        });
    }
}
